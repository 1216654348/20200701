﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication1.HangFire
{
    public static class Test
    {
        public static List<DateTime> str { get; set; } = new List<DateTime>();
    }



}
