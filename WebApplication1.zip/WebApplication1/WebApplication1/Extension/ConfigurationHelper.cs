﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication1.Extension
{
    public class ConfigurationHelper
    {
        public static IConfiguration Configuration { get; set; }

    }
}
