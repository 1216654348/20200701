﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LocalHostModel
{
    public partial class TTempCxph
    {
        public string Id { get; set; }
        public DateTime? Cjsj { get; set; }
        public string Cllx { get; set; }
        public decimal? Czbl { get; set; }
        public DateTime? Rksj { get; set; }
    }
}
