﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LocalHostModel
{
    public partial class TTempKyjgs
    {
        public string Id { get; set; }
        public DateTime? Cjsj { get; set; }
        public string Dyfb { get; set; }
        public decimal? Qgzb { get; set; }
        public DateTime? Rksj { get; set; }
    }
}
