﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LocalHostModel
{
    public partial class TTempGgcl
    {
        public string Id { get; set; }
        public DateTime? Cjsj { get; set; }
        public int? Allusesightcarnum { get; set; }
        public int? Inusesightcarnum { get; set; }
        public int? Remainsightcarnum { get; set; }
        public int? Faultsightcarnum { get; set; }
        public DateTime? Rksj { get; set; }
    }
}
