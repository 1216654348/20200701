﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LocalHostModel
{
    public partial class TTempYqrs
    {
        public string Id { get; set; }
        public DateTime? Cjsj { get; set; }
        public string Rsmc { get; set; }
        public int? Rssl { get; set; }
        public DateTime? Rksj { get; set; }
    }
}
