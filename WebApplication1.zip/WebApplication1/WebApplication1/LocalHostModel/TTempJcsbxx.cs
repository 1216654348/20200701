﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LocalHostModel
{
    public partial class TTempJcsbxx
    {
        public string Id { get; set; }
        public DateTime? Cjsj { get; set; }
        public int? Inusegatenum { get; set; }
        public int? Remaingatenum { get; set; }
        public int? Remainparknum { get; set; }
        public int? Inuseparknum { get; set; }
        public int? Inusesightcarnum { get; set; }
        public DateTime? Rksj { get; set; }
    }
}
