﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LocalHostModel
{
    public partial class TTempKyjgcs
    {
        public string Id { get; set; }
        public DateTime? Cjsj { get; set; }
        public string Dyfb { get; set; }
        public decimal? Bszb { get; set; }
        public DateTime? Rksj { get; set; }
    }
}
