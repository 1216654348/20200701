﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LocalHostModel
{
    public partial class TTempRkll
    {
        public string Id { get; set; }
        public DateTime? Cjsj { get; set; }
        public string Rkmc { get; set; }
        public decimal? Rkrsbl { get; set; }
        public DateTime? Rksj { get; set; }
    }
}
