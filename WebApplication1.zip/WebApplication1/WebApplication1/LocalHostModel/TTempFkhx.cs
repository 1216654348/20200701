﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LocalHostModel
{
    public partial class TTempFkhx
    {
        public string Id { get; set; }
        public DateTime? Cjsj { get; set; }
        public decimal Unknownage { get; set; }
        public decimal _19 { get; set; }
        public decimal _1925 { get; set; }
        public decimal _2635 { get; set; }
        public decimal _3645 { get; set; }
        public decimal _4655 { get; set; }
        public decimal _55 { get; set; }
        public decimal Femalerate { get; set; }
        public decimal Malerate { get; set; }
        public decimal Unknownrate { get; set; }
        public DateTime? Rksj { get; set; }
    }
}
