﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LocalHostModel
{
    public partial class TTempYjzh
    {
        public string Id { get; set; }
        public DateTime? Cjsj { get; set; }
        public string Emergencyindex { get; set; }
        public string Emergencytype { get; set; }
        public string Longitude { get; set; }
        public string Latitude { get; set; }
        public DateTime? Rksj { get; set; }
    }
}
