﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LocalHostModel
{
    public partial class TTempYkll
    {
        public string Id { get; set; }
        public DateTime? Cjsj { get; set; }
        public int? Preentrancecount { get; set; }
        public int? Totalcount { get; set; }
        public DateTime? Rksj { get; set; }
    }
}
