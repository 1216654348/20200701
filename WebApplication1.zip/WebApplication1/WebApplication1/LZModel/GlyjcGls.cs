﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcGls
    {
        public string Id { get; set; }
        public string Ryid { get; set; }
        public string Gls { get; set; }
        public DateTime? Rq { get; set; }
        public string Sfzx { get; set; }
        public string Xcgj { get; set; }
        public DateTime? Rksj { get; set; }
    }
}
