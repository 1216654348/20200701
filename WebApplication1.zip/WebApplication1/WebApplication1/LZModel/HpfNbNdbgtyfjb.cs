﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class HpfNbNdbgtyfjb
    {
        public string Id { get; set; }
        public string Pid { get; set; }
        public string Sjid { get; set; }
        public DateTime? Cjsj { get; set; }
        public string Typename { get; set; }
        public string Ljvalue { get; set; }
        public string Mcvalue { get; set; }
        public string Gsvalue { get; set; }
        public string Lxvalue { get; set; }
        public string Scridvalue { get; set; }
        public DateTime? Rksj { get; set; }
        public int? Px { get; set; }
    }
}
