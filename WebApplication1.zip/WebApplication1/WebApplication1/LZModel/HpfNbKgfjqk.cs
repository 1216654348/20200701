﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class HpfNbKgfjqk
    {
        public string Id { get; set; }
        public string Ndbgid { get; set; }
        public DateTime? Cjsj { get; set; }
        public string Xmmcvalue { get; set; }
        public string Wwbmpzwhvalue { get; set; }
        public decimal? Pzfjmjvalue { get; set; }
        public string Kssjvalue { get; set; }
        public string Jssjvalue { get; set; }
        public decimal? Fjmjvalue { get; set; }
        public decimal? Htmjvalue { get; set; }
        public decimal? Jftrzevalue { get; set; }
        public decimal? Yyfjxcbhdjfvalue { get; set; }
        public DateTime? Rksj { get; set; }
        public sbyte? Isavailable { get; set; }
        public int? Sort { get; set; }
        public int? Wzxs { get; set; }
    }
}
