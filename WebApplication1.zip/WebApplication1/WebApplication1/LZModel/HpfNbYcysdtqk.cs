﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class HpfNbYcysdtqk
    {
        public string Id { get; set; }
        public string Ndbgid { get; set; }
        public string Ycysdtsfybhvalue { get; set; }
        public string Msvalue { get; set; }
        public DateTime? Rksj { get; set; }
        public DateTime? Cjsj { get; set; }
        public int? Sort { get; set; }
        public int? Wzxs { get; set; }
        public sbyte? Isavailable { get; set; }
    }
}
