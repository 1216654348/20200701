﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcYjxxCopy1
    {
        public string Id { get; set; }
        public string Cjrid { get; set; }
        public DateTime? Cjsj { get; set; }
        public sbyte? Sfkdj { get; set; }
        public string Shyc { get; set; }
        public DateTime? Djsj { get; set; }
        public string Yjpzfaid { get; set; }
        public string Cjsjid { get; set; }
        public DateTime? Fbsj { get; set; }
        public string Yjdj { get; set; }
        public string Cjsjbid { get; set; }
        public string Yjxxsm { get; set; }
        public string Yjyaid { get; set; }
        public string Yjsfjc { get; set; }
        public sbyte? Sfydj { get; set; }
        public string Djrid { get; set; }
        public string Yjslzt { get; set; }
        public string Slsm { get; set; }
        public DateTime? Slsj { get; set; }
        public string Yjdx { get; set; }
        public double? Jd { get; set; }
        public double? Wd { get; set; }
        public string Ycysid { get; set; }
    }
}
