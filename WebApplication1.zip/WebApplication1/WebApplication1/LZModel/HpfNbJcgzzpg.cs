﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class HpfNbJcgzzpg
    {
        public string Id { get; set; }
        public string Ndbgid { get; set; }
        public DateTime? Cjsj { get; set; }
        public string Jfsyvalue { get; set; }
        public string Jcsbsyvalue { get; set; }
        public string Jcgzxgvalue { get; set; }
        public string Gzbhjyvalue { get; set; }
        public DateTime? Rksj { get; set; }
        public int? Sort { get; set; }
        public int? Wzxs { get; set; }
    }
}
