﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcRypftjCopy20181107qhx
    {
        public string Id { get; set; }
        public string Ryid { get; set; }
        public int? Rylb { get; set; }
        public int? Rwsl { get; set; }
        public DateTime? Pgyf { get; set; }
        public int? Ywcrws { get; set; }
        public int? Ygqrws { get; set; }
        public int? Sjtjsl { get; set; }
        public int? Shtgsjl { get; set; }
        public int? Shbtgsjl { get; set; }
        public double? Gls { get; set; }
        public int? Yctjsl { get; set; }
        public int? Ycjcsl { get; set; }
        public string Fzqy { get; set; }
        public int? Qyxcdsl { get; set; }
        public int? Qyqddsl { get; set; }
        public int? Qyyjsl { get; set; }
        public int? Qyyjjcsl { get; set; }
        public double? Pf { get; set; }
        public int? Xshsjzl { get; set; }
        public int? Ywcshsjl { get; set; }
        public int? Ygqshsjl { get; set; }
        public int? Dwcshsjl { get; set; }
    }
}
