﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcCnsxjz
    {
        public string Id { get; set; }
        public string Nf { get; set; }
        public string Cnsxly { get; set; }
        public string CnsxnrYw { get; set; }
        public string CnsxnrZw { get; set; }
        public DateTime? Cnwcsj { get; set; }
        public string Mqjz { get; set; }
        public string Dwcqkdbysm { get; set; }
        public string Xgwd { get; set; }
        public string Cnsxid { get; set; }
        public string Cjrid { get; set; }
        public DateTime? Cjsj { get; set; }
        public string Shrid { get; set; }
        public DateTime? Shsj { get; set; }
        public sbyte? Shzt { get; set; }
        public string Shbtgsm { get; set; }
        public sbyte? Sfkdj { get; set; }
        public string Djrid { get; set; }
        public DateTime? Djsj { get; set; }
        public sbyte? Sfydj { get; set; }
        public string Rwid { get; set; }
        public string Shyc { get; set; }
        public DateTime? Tjsj { get; set; }
    }
}
