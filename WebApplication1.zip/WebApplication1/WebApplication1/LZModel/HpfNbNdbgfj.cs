﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class HpfNbNdbgfj
    {
        public string Id { get; set; }
        public string Ndbgid { get; set; }
        public string Lx { get; set; }
        public string Lj { get; set; }
        public string Fjmc { get; set; }
        public DateTime? Rksj { get; set; }
        public int? Px { get; set; }
    }
}
