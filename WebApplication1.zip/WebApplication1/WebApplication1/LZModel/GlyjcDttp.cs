﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcDttp
    {
        public string Id { get; set; }
        public string Mc { get; set; }
        public DateTime? Cjsj { get; set; }
    }
}
