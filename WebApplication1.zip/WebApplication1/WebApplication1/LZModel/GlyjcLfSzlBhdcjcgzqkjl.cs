﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcLfSzlBhdcjcgzqkjl
    {
        public string Id { get; set; }
        public string Bhbh { get; set; }
        public sbyte? Shzt { get; set; }
        public int? Kd { get; set; }
        public string Bhmc { get; set; }
        public double? Bhjd { get; set; }
        public double? Bhwd { get; set; }
    }
}
