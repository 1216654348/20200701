﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcJcpzrybb
    {
        public string Id { get; set; }
        public string Jcpzid { get; set; }
        public string Jcxid { get; set; }
        public string Sjcjfzrid { get; set; }
        public DateTime? Qssj { get; set; }
        public DateTime? Jssj { get; set; }
        public string Jcpzysjid { get; set; }
        public string Lrfs { get; set; }
    }
}
