﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcYjwz
    {
        public string Id { get; set; }
        public string Qyid { get; set; }
        public string Zbxx { get; set; }
        public string Yjxxid { get; set; }
    }
}
