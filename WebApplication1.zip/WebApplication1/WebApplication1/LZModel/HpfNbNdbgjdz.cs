﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class HpfNbNdbgjdz
    {
        public string Id { get; set; }
        public string Ndbgid { get; set; }
        public string Lx { get; set; }
        public string Bm { get; set; }
        public string Nf { get; set; }
        public double? Jdz { get; set; }
        public DateTime? Rksj { get; set; }
        public string Jdx { get; set; }
    }
}
