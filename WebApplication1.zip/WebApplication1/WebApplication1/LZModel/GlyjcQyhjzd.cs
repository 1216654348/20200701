﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcQyhjzd
    {
        public string Id { get; set; }
        public string Fs { get; set; }
        public string Fx { get; set; }
        public string Yl { get; set; }
        public string Qw { get; set; }
        public string Xdsd { get; set; }
        public string Qy { get; set; }
        public string Tyfu { get; set; }
        public string Cjrid { get; set; }
        public DateTime? Cjsj { get; set; }
        public string Shrid { get; set; }
        public DateTime? Shsj { get; set; }
        public sbyte? Shzt { get; set; }
        public string Shbtgsm { get; set; }
        public sbyte? Sfkdj { get; set; }
        public string Djrid { get; set; }
        public DateTime? Djsj { get; set; }
        public sbyte? Sfydj { get; set; }
        public string Shyc { get; set; }
        public DateTime? Tjsj { get; set; }
        public string Rwid { get; set; }
        public string Zpmc { get; set; }
    }
}
