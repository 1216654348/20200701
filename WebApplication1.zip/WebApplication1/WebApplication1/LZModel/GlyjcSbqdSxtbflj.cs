﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcSbqdSxtbflj
    {
        public string Id { get; set; }
        public string Sbid { get; set; }
        public string Rtmp { get; set; }
        public string Resid { get; set; }
        public string Islive { get; set; }
        public string Flv { get; set; }
        public string M3u8 { get; set; }
        public string Mp4 { get; set; }
        public string Filename { get; set; }
        public string Ip { get; set; }
        public sbyte? Sfjt { get; set; }
        public string Devid { get; set; }
        public string Dtjcsjid { get; set; }
    }
}
