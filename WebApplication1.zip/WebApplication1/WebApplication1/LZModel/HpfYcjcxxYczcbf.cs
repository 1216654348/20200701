﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class HpfYcjcxxYczcbf
    {
        public string Id { get; set; }
        public string Pid { get; set; }
        public string Bm { get; set; }
        public string Sjwhycbm { get; set; }
        public string Mc { get; set; }
        public string Ywmc { get; set; }
        public string Gk { get; set; }
        public string Xzqbm { get; set; }
        public string Wzsm { get; set; }
        public decimal? Jd { get; set; }
        public decimal? Wd { get; set; }
        public string Dbzp { get; set; }
        public string Xzgn { get; set; }
        public DateTime Rksj { get; set; }
        public string Zzjgbh { get; set; }
        public int? Level { get; set; }
        public int? Sort { get; set; }
        public string Fid { get; set; }
    }
}
