﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class HpfJcbgYj
    {
        public string Id { get; set; }
        public string Yj { get; set; }
        public DateTime? Sj { get; set; }
        public string Ybid { get; set; }
    }
}
