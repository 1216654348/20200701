﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcSystem
    {
        public string Id { get; set; }
        public string Sysname { get; set; }
        public sbyte? Index { get; set; }
    }
}
