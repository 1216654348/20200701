﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcJrjcjg
    {
        public string Id { get; set; }
        public string Jrpzid { get; set; }
        public string Jrjglxid { get; set; }
        public DateTime? Cjsj { get; set; }
        public string Cjrid { get; set; }
        public string Jrjg { get; set; }
        public int? Jcpc { get; set; }
        public DateTime? Jckssj { get; set; }
        public DateTime? Jcjssj { get; set; }
    }
}
