﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class Geodatabase
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
