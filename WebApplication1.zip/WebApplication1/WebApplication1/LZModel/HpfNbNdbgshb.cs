﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class HpfNbNdbgshb
    {
        public string Id { get; set; }
        public string Ndbgid { get; set; }
        public string Typename { get; set; }
        public string Typeid { get; set; }
        public string Shr { get; set; }
        public string Shrid { get; set; }
        public string Shzt { get; set; }
        public string Shyj { get; set; }
        public sbyte? Sftj { get; set; }
        public DateTime? Rksj { get; set; }
        public string Zyzt { get; set; }
        public string Zyyj { get; set; }
    }
}
