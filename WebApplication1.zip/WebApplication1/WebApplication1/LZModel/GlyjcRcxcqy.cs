﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcRcxcqy
    {
        public string Id { get; set; }
        public string Qymc { get; set; }
        public string Sx { get; set; }
        public string Dqymc { get; set; }
        public string Fzrid { get; set; }
        public string Qyzb { get; set; }
        public string Bz { get; set; }
        public string Cjrid { get; set; }
        public DateTime? Cjsj { get; set; }
        public string Ycqid { get; set; }
    }
}
