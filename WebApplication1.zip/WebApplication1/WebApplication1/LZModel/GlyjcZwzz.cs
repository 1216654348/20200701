﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcZwzz
    {
        public string Id { get; set; }
        public string Cjrid { get; set; }
        public DateTime? Cjsj { get; set; }
        public string Shyc { get; set; }
        public DateTime? Tjsj { get; set; }
        public string Zzjgid { get; set; }
        public string Zwmc { get; set; }
        public string Bm { get; set; }
        public string Zwfw { get; set; }
        public string Zqsm { get; set; }
        public string Zryq { get; set; }
        public string Bz { get; set; }
    }
}
