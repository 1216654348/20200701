﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcWrj
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public DateTime? Date { get; set; }
        public string Jd { get; set; }
        public string Wd { get; set; }
        public string Lx { get; set; }
    }
}
