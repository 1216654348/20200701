﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcPgZjxx
    {
        public string Id { get; set; }
        public string Yhid { get; set; }
        public string Zjfl { get; set; }
        public string Gzdw { get; set; }
        public string Zc { get; set; }
        public string Byyx { get; set; }
        public string Sxzy { get; set; }
        public string Lxdh { get; set; }
        public string Yx { get; set; }
        public sbyte? Xb { get; set; }
        public string Gj { get; set; }
        public string Mz { get; set; }
        public DateTime? Cjsj { get; set; }
        public string Cjrid { get; set; }
        public string Shrid { get; set; }
        public DateTime? Shsj { get; set; }
        public sbyte? Shzt { get; set; }
        public string Shyc { get; set; }
        public string Shbtgsm { get; set; }
        public sbyte? Sfkdj { get; set; }
        public string Djrid { get; set; }
        public DateTime? Djsj { get; set; }
        public sbyte? Sfydj { get; set; }
    }
}
