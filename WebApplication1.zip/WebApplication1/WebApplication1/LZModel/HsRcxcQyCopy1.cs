﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class HsRcxcQyCopy1
    {
        public string Id { get; set; }
        public string Glycbtid { get; set; }
        public string Qymc { get; set; }
        public string Cjrid { get; set; }
        public string Path { get; set; }
    }
}
