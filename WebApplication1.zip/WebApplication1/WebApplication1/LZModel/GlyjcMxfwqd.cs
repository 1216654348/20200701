﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcMxfwqd
    {
        public string Id { get; set; }
        public string Fwmc { get; set; }
    }
}
