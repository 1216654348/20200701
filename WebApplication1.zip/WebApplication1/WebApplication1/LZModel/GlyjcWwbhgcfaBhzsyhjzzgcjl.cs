﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcWwbhgcfaBhzsyhjzzgcjl
    {
        public string Id { get; set; }
        public string Cjrid { get; set; }
        public DateTime? Cjsj { get; set; }
        public sbyte? Sfkdj { get; set; }
        public string Djrid { get; set; }
        public DateTime? Djsj { get; set; }
        public sbyte? Sfydj { get; set; }
        public string Shyc { get; set; }
        public DateTime? Tjsj { get; set; }
        public string Famc { get; set; }
        public string Bzdw { get; set; }
        public string Pzwh { get; set; }
        public string Wdfj { get; set; }
        public string Tjrid { get; set; }
        public string Gcid { get; set; }
        public string Shrid { get; set; }
        public DateTime? Shsj { get; set; }
        public sbyte? Shzt { get; set; }
        public string Shbtgsm { get; set; }
        public string Pfwjmc { get; set; }
        public DateTime? Kssj { get; set; }
        public string Pfnf { get; set; }
        public string Gjbz { get; set; }
        public string Dfpt { get; set; }
        public string Btywj { get; set; }
        public string Sfsb { get; set; }
        public string Xmmc { get; set; }
    }
}
