﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcQtxggh
    {
        public string Id { get; set; }
        public string Cjrid { get; set; }
        public DateTime? Cjsj { get; set; }
        public sbyte? Sfkdj { get; set; }
        public string Djrid { get; set; }
        public DateTime? Djsj { get; set; }
        public sbyte? Sfydj { get; set; }
        public string Shyc { get; set; }
        public DateTime? Tjsj { get; set; }
        public string Lx { get; set; }
        public string Ghqx { get; set; }
        public string Mc { get; set; }
        public string Zzbzdw { get; set; }
        public string Bzdw { get; set; }
        public string Wdfj { get; set; }
        public string Tjrid { get; set; }
    }
}
