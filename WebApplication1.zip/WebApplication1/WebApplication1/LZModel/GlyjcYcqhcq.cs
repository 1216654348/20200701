﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcYcqhcq
    {
        public string Id { get; set; }
        public string Cjrid { get; set; }
        public DateTime? Cjsj { get; set; }
        public string Shrid { get; set; }
        public DateTime? Shsj { get; set; }
        public sbyte? Shzt { get; set; }
        public string Shbtgsm { get; set; }
        public sbyte? Sfkdj { get; set; }
        public string Djrid { get; set; }
        public DateTime? Djsj { get; set; }
        public sbyte? Sfydj { get; set; }
        public string Shyc { get; set; }
        public DateTime? Tjsj { get; set; }
        public string Ycqjx { get; set; }
        public double? Ycqmj { get; set; }
        public string Ycqglgd { get; set; }
        public string Hcqjx { get; set; }
        public double? Hcqmj { get; set; }
        public string Hcqglgd { get; set; }
        public string Bizid { get; set; }
        public string Onlyid { get; set; }
    }
}
