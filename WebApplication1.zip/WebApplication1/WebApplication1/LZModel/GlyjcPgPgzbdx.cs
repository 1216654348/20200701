﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcPgPgzbdx
    {
        public string Id { get; set; }
        public string Dxmc { get; set; }
        public string Dxbid { get; set; }
        public string Dxid { get; set; }
        public string Jcdxlx { get; set; }
        public string Jcxbid { get; set; }
        public string Wjzd { get; set; }
        public DateTime? Cjsj { get; set; }
    }
}
