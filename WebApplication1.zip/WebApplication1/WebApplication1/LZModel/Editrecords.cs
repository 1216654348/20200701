﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class Editrecords
    {
        public int Id { get; set; }
        public int? Onlyid { get; set; }
        public string Businesskey { get; set; }
        public int? Featurestate { get; set; }
        public double? Date { get; set; }
        public string Tablename { get; set; }
        public int? Edittype { get; set; }
        public string User { get; set; }
        public string Operatekey { get; set; }
        public int? Ponlyid { get; set; }
        public string Ptablename { get; set; }
    }
}
