﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class HpfNbZdbhjcqk
    {
        public string Id { get; set; }
        public string Ndbgid { get; set; }
        public DateTime? Cjsj { get; set; }
        public string Ycysvalue { get; set; }
        public string Ycyslxvalue { get; set; }
        public string Bhlxvalue { get; set; }
        public string Jckssjvalue { get; set; }
        public string Jcjssjvalue { get; set; }
        public string Jcffvalue { get; set; }
        public string Jczqvalue { get; set; }
        public string Ssjgvalue { get; set; }
        public sbyte? Issctp { get; set; }
        public DateTime? Rksj { get; set; }
        public int? Sort { get; set; }
        public int? Wzxs { get; set; }
    }
}
