﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcJbhjCopy20181227qhx
    {
        public string Id { get; set; }
        public string Jcdid { get; set; }
        public DateTime? Jcsj { get; set; }
        public double? Pm25 { get; set; }
        public int? Co2 { get; set; }
        public double? Zs { get; set; }
        public double? Fylz { get; set; }
        public double? Ph { get; set; }
        public int? Gzd { get; set; }
        public double? Yf { get; set; }
        public double? Dqsd { get; set; }
        public double? Trsd { get; set; }
        public double? Fx { get; set; }
        public double? Jyzfs { get; set; }
        public double? Szqy { get; set; }
        public double? Trwd { get; set; }
        public double? Dqwd { get; set; }
        public double? Yl { get; set; }
        public double? Yllj { get; set; }
        public double? Fs { get; set; }
        public string Cjrid { get; set; }
        public DateTime? Cjsj { get; set; }
        public string Shrid { get; set; }
        public DateTime? Shsj { get; set; }
        public int? Shzt { get; set; }
        public string Shtbgsm { get; set; }
        public sbyte? Sfkdj { get; set; }
        public string Djrid { get; set; }
        public DateTime? Djsj { get; set; }
        public byte? Sfydj { get; set; }
        public string Shyc { get; set; }
        public DateTime? Tjsj { get; set; }
    }
}
