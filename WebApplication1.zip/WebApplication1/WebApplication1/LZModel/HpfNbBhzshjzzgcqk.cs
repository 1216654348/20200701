﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class HpfNbBhzshjzzgcqk
    {
        public string Id { get; set; }
        public string Ndbgid { get; set; }
        public DateTime? Cjsj { get; set; }
        public string Xmmcvalue { get; set; }
        public string Gcxmlxvalue { get; set; }
        public string Xmztvalue { get; set; }
        public string Wwbmpzxkwhvalue { get; set; }
        public string Dgsjvalue { get; set; }
        public string Jgsjvalue { get; set; }
        public decimal? Jftrzevalue { get; set; }
        public decimal? Zyczjfvalue { get; set; }
        public string Bzvalue { get; set; }
        public DateTime? Rksj { get; set; }
        public sbyte? Isavailable { get; set; }
        public int? Sort { get; set; }
        public sbyte? Issctp { get; set; }
        public int? Wzxs { get; set; }
        public string Yssjvalue { get; set; }
        public string Yswhvalue { get; set; }
    }
}
