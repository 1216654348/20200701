﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class ConJcxJcd
    {
        public string Id { get; set; }
        public string Jcxid { get; set; }
        public string Jcxbm { get; set; }
        public string Jcdbm { get; set; }
    }
}
