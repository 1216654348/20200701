﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcYczbb
    {
        public long Id { get; set; }
        public string Lx { get; set; }
        public string Zb { get; set; }
    }
}
