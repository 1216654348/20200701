﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class JczlStzlcfwz
    {
        public string Id { get; set; }
        public string Wzbm { get; set; }
        public string Mc { get; set; }
        public string Lx { get; set; }
        public string Bzsm { get; set; }
        public string Fjid { get; set; }
        public string Cjrid { get; set; }
        public DateTime? Cjsj { get; set; }
    }
}
