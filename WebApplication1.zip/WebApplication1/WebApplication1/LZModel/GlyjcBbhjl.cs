﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcBbhjl
    {
        public string Id { get; set; }
        public string Jcbid { get; set; }
        public int? Bbh { get; set; }
        public DateTime? Qssj { get; set; }
        public DateTime? Jzsj { get; set; }
    }
}
