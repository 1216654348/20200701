﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class HpfNbZxfggzqk
    {
        public string Id { get; set; }
        public string Ndbgid { get; set; }
        public string Lbvalue { get; set; }
        public string Mcvalue { get; set; }
        public string Gbsjvalue { get; set; }
        public string Gbwhvalue { get; set; }
        public string Sssjvalue { get; set; }
        public string Gbdwvalue { get; set; }
        public DateTime? Rksj { get; set; }
        public DateTime? Cjsj { get; set; }
        public int? Sort { get; set; }
        public int? Wzxs { get; set; }
    }
}
