﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcFjb1
    {
        public string Id { get; set; }
        public string Bid { get; set; }
        public string Sjid { get; set; }
        public string Fjdyzdm { get; set; }
        public string Ccmc { get; set; }
        public string Wjmc { get; set; }
        public DateTime? Cjsj { get; set; }
    }
}
