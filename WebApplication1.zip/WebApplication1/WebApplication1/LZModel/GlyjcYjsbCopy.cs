﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcYjsbCopy
    {
        public string Id { get; set; }
        public string Yjxxid { get; set; }
        public string Cjrid { get; set; }
        public DateTime? Cjsj { get; set; }
        public string Sbfs { get; set; }
        public string Sbr { get; set; }
        public DateTime? Sbsj { get; set; }
        public string Jsr { get; set; }
        public string Jsrbmid { get; set; }
        public string Shrid { get; set; }
        public DateTime? Shsj { get; set; }
        public sbyte? Shzt { get; set; }
        public string Shbtgsm { get; set; }
        public string Shyc { get; set; }
        public string Fjmc { get; set; }
    }
}
