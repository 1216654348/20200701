﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcBhgljg
    {
        public string Id { get; set; }
        public string Jgmc { get; set; }
        public string Zzjgdm { get; set; }
        public string Szxzq { get; set; }
        public string Cddzr { get; set; }
        public string Glqysm { get; set; }
        public string Glqyzrfwtlj { get; set; }
        public string Fddbr { get; set; }
        public string Lxrxm { get; set; }
        public string Lxdh { get; set; }
        public string Dzyx { get; set; }
        public string Gfwz { get; set; }
        public string Sjgldw { get; set; }
        public DateTime? Jgclsj { get; set; }
        public string Jgjb { get; set; }
        public int? Bzrs { get; set; }
        public int? Gzryzs { get; set; }
        public string Zyjfly { get; set; }
        public DateTime? Jgcxsj { get; set; }
        public string Cjrid { get; set; }
        public DateTime? Cjsj { get; set; }
        public string Shrid { get; set; }
        public DateTime? Shsj { get; set; }
        public sbyte? Shzt { get; set; }
        public string Shbtgsm { get; set; }
        public sbyte? Sfkdj { get; set; }
        public string Djrid { get; set; }
        public DateTime? Djsj { get; set; }
        public sbyte? Sfydj { get; set; }
        public string Shyc { get; set; }
        public DateTime? Tjsj { get; set; }
    }
}
