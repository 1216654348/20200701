﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcRhwzp
    {
        public string Id { get; set; }
        public string Sbid { get; set; }
        public DateTime? Jcsj { get; set; }
        public string Rhw { get; set; }
        public string Kjg { get; set; }
        public string Bz { get; set; }
        public string Cjrid { get; set; }
        public DateTime? Cjsj { get; set; }
        public string Shrid { get; set; }
        public DateTime? Shsj { get; set; }
        public sbyte? Shzt { get; set; }
        public string Shbtgsm { get; set; }
        public string Shyc { get; set; }
        public string Djrid { get; set; }
        public DateTime? Djsj { get; set; }
        public string Ssdgspg { get; set; }
        public string Ssmjpg { get; set; }
        public string Fhblmjpg { get; set; }
    }
}
