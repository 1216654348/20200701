﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcPgPgjlzbdx
    {
        public string Id { get; set; }
        public string Jcdxmc { get; set; }
        public string Jcdxbid { get; set; }
        public string Jcdxid { get; set; }
        public sbyte? Jcdxlx { get; set; }
        public double? Jd { get; set; }
        public double? Wd { get; set; }
    }
}
