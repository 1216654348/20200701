﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class HpfNbYcdztpg
    {
        public string Id { get; set; }
        public string Ndbgid { get; set; }
        public DateTime? Cjsj { get; set; }
        public string Sycnvalue { get; set; }
        public string Rypxvalue { get; set; }
        public string Jcxxwsvalue { get; set; }
        public string Ycztgjvalue { get; set; }
        public string Ycsygnvalue { get; set; }
        public string Ycysxsvalue { get; set; }
        public string Bhbhvalue { get; set; }
        public string Hjysvalue { get; set; }
        public string Xjxmvalue { get; set; }
        public string Tdlybhvalue { get; set; }
        public string Ykfmyxvalue { get; set; }
        public string Rcglvalue { get; set; }
        public string Kgfjvalue { get; set; }
        public string Aqsgvalue { get; set; }
        public string Bhzsvalue { get; set; }
        public string Bhglvalue { get; set; }
        public DateTime? Rksj { get; set; }
        public string Funiditem { get; set; }
        public int? Sort { get; set; }
        public int? Wzxs { get; set; }
    }
}
