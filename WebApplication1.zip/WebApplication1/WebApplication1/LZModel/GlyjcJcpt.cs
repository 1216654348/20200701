﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcJcpt
    {
        public string Id { get; set; }
        public DateTime? Jssj { get; set; }
        public string Cjdw { get; set; }
        public string Xtxz { get; set; }
        public string Cjrid { get; set; }
        public DateTime? Cjsj { get; set; }
        public string Shrid { get; set; }
        public DateTime? Shsj { get; set; }
        public sbyte? Shzt { get; set; }
        public string Shbtgsm { get; set; }
        public string Shyc { get; set; }
        public sbyte? Sfydj { get; set; }
        public string Djrid { get; set; }
        public DateTime? Djsj { get; set; }
    }
}
