﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcXjxmjl
    {
        public string Id { get; set; }
        public string Cjrid { get; set; }
        public DateTime? Cjsj { get; set; }
        public string Shrid { get; set; }
        public DateTime? Shsj { get; set; }
        public sbyte? Shzt { get; set; }
        public string Shbtgsm { get; set; }
        public sbyte? Sfkdj { get; set; }
        public string Djrid { get; set; }
        public DateTime? Djsj { get; set; }
        public sbyte? Sfydj { get; set; }
        public string Shyc { get; set; }
        public DateTime? Tjsj { get; set; }
        public string Xjxmbh { get; set; }
        public string Xmmc { get; set; }
        public string Lb { get; set; }
        public string Jsmd { get; set; }
        public string Jsdd { get; set; }
        public DateTime? Kgsj { get; set; }
        public DateTime? Jgsj { get; set; }
        public string Wwbmpzxkwh { get; set; }
        public double? Zdmj { get; set; }
        public double? Gd { get; set; }
        public string Xmjswztlj { get; set; }
        public string Xjxmgcfa { get; set; }
        public sbyte? Sfazjsxkdfajx { get; set; }
        public string Onlyid { get; set; }
        public string Sfzdwwbmty { get; set; }
        public string Xmlb { get; set; }
        public string Wjhqff { get; set; }
        public double? Jd { get; set; }
        public double? Wd { get; set; }
        public string Xmwz { get; set; }
        public string Syt { get; set; }
        public string Rwid { get; set; }
        public string Mjjzz { get; set; }
        public string Gdjzz { get; set; }
        public string Csjzz { get; set; }
        public string Scjzz { get; set; }
        public string Xsjzz { get; set; }
        public string Qtjzz { get; set; }
        public string Spyq { get; set; }
    }
}
