﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcJksjjrpzb
    {
        public string Paraid { get; set; }
        public double? Jcsd { get; set; }
        public string Jcfx { get; set; }
        public string Jczbmc { get; set; }
        public string Dw { get; set; }
        public string Sbid { get; set; }
        public sbyte? Sfsx { get; set; }
        public DateTime? Cjsj { get; set; }
        public string Cjrid { get; set; }
        public string Shrid { get; set; }
        public DateTime? Shsj { get; set; }
        public string Shyc { get; set; }
        public sbyte? Shzt { get; set; }
        public string Bz { get; set; }
    }
}
