﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcZzjg
    {
        public string Id { get; set; }
        public string Cjrid { get; set; }
        public DateTime? Cjsj { get; set; }
        public string Shyc { get; set; }
        public DateTime? Tjsj { get; set; }
        public string Zzjgmc { get; set; }
        public string Bm { get; set; }
        public string Fjjgid { get; set; }
        public string Sm { get; set; }
        public string Zzjgzz { get; set; }
        public string Dz { get; set; }
        public string Wz { get; set; }
        public string Zzjgdm { get; set; }
        public string X { get; set; }
        public string Y { get; set; }
        public string Bz { get; set; }
        public DateTime? Cxrq { get; set; }
        public string Xzqbm { get; set; }
    }
}
