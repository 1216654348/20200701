﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class HpfNbBhglryqk
    {
        public string Id { get; set; }
        public string Ndbgid { get; set; }
        public int? Bhglryzsvalue { get; set; }
        public int? Zbrsvalue { get; set; }
        public int? Bsyjsrsvalue { get; set; }
        public int? Ssyjsrsvalue { get; set; }
        public int? Bkryslvalue { get; set; }
        public int? Zkryslvalue { get; set; }
        public int? Qtxlvalue { get; set; }
        public int? Zhglryslvalue { get; set; }
        public int? Zyjsryslvalue { get; set; }
        public int? Zzcsjcdryslvalue { get; set; }
        public int? Csycbhdryslvalue { get; set; }
        public int? Qtzgvalue { get; set; }
        public int? Gjzcrsvalue { get; set; }
        public int? Zjzcrsvalue { get; set; }
        public int? Cjzcrsvalue { get; set; }
        public int? Qtzcrsvalue { get; set; }
        public string Zygcvalue { get; set; }
        public DateTime? Rksj { get; set; }
        public DateTime? Cjsj { get; set; }
        public int? Sort { get; set; }
        public int? Wzxs { get; set; }
    }
}
