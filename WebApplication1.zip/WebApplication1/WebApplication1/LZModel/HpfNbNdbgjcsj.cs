﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class HpfNbNdbgjcsj
    {
        public string Id { get; set; }
        public string Ndbgid { get; set; }
        public string Funid { get; set; }
        public string Sfjcsj { get; set; }
        public string Typename { get; set; }
        public DateTime? Rksj { get; set; }
    }
}
