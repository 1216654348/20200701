﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class CljqrLfpoints
    {
        public string Id { get; set; }
        public string Pot1 { get; set; }
        public string Pot2 { get; set; }
        public string Pic { get; set; }
        public double? Csjl { get; set; }
        public string Ycysid { get; set; }
    }
}
