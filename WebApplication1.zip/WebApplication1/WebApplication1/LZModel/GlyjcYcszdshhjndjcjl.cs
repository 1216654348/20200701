﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcYcszdshhjndjcjl
    {
        public string Id { get; set; }
        public string Cjrid { get; set; }
        public DateTime? Cjsj { get; set; }
        public string Shrid { get; set; }
        public DateTime? Shsj { get; set; }
        public sbyte? Shzt { get; set; }
        public string Shbtgsm { get; set; }
        public sbyte? Sfkdj { get; set; }
        public string Djrid { get; set; }
        public DateTime? Djsj { get; set; }
        public sbyte? Sfydj { get; set; }
        public string Shyc { get; set; }
        public string Tjrid { get; set; }
        public DateTime? Tjsj { get; set; }
        public double? Rkmd { get; set; }
        public double? Rjgdp { get; set; }
        public int? Gjbhdzwzl { get; set; }
        public double? Zbfgl { get; set; }
        public int? Ycszdyzwrgyqysl { get; set; }
        public string Rwid { get; set; }
        public string Nd { get; set; }
    }
}
