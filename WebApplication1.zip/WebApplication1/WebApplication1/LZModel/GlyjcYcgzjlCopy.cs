﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcYcgzjlCopy
    {
        public string Id { get; set; }
        public string Ycid { get; set; }
        public DateTime? Cjsj { get; set; }
        public string Ms { get; set; }
        public string Xczp { get; set; }
        public string Sfbj { get; set; }
        public string Rwid { get; set; }
        public string Cjrid { get; set; }
        public string Dscqdcs { get; set; }
    }
}
