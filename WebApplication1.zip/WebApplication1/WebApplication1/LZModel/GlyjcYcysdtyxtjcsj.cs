﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcYcysdtyxtjcsj
    {
        public string Id { get; set; }
        public string Mc { get; set; }
        public string Cjdwzms { get; set; }
        public double? Cjdjd { get; set; }
        public double? Cjdwd { get; set; }
        public string Cjdsyt { get; set; }
        public string Cjrid { get; set; }
        public DateTime? Cjsj { get; set; }
        public string Shrid { get; set; }
        public DateTime? Shsj { get; set; }
        public sbyte? Shzt { get; set; }
        public string Shbtgsm { get; set; }
        public sbyte? Sfkdj { get; set; }
        public string Djrid { get; set; }
        public DateTime? Djsj { get; set; }
        public sbyte? Sfydj { get; set; }
        public string Shyc { get; set; }
        public DateTime? Tjsj { get; set; }
        public string Bizid { get; set; }
        public string Jzzp { get; set; }
        public string Ycysid { get; set; }
        public string Jd { get; set; }
        public string Wd { get; set; }
        public string Rwid { get; set; }
        public string Cjfs { get; set; }
    }
}
