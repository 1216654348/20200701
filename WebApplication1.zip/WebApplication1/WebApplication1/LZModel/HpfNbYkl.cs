﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class HpfNbYkl
    {
        public string Id { get; set; }
        public string Ndbgid { get; set; }
        public DateTime? Cjsj { get; set; }
        public int? Qnykzlvalue { get; set; }
        public int? Zgqyklvalue { get; set; }
        public string Zgrykrqvalue { get; set; }
        public int? Ssyklxzzvalue { get; set; }
        public int? Ryklxzzvalue { get; set; }
        public int? Cgsjykrltsvalue { get; set; }
        public int? Yyyrcsvalue { get; set; }
        public int? Gwykrcsvalue { get; set; }
        public int? Jjyjjcsvalue { get; set; }
        public int? Jjyfwrsvalue { get; set; }
        public int? Bsykslvalue { get; set; }
        public DateTime? Rksj { get; set; }
        public int? Sort { get; set; }
        public int? Wzxs { get; set; }
        public string Msvalue { get; set; }
    }
}
