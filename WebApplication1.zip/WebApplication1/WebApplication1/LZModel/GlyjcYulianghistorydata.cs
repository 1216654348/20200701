﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcYulianghistorydata
    {
        public string Id { get; set; }
        public int? Xh { get; set; }
        public string Nf { get; set; }
        public double? Nyl { get; set; }
        public string Cjrid { get; set; }
        public DateTime? Cjsj { get; set; }
        public string Shrid { get; set; }
        public DateTime? Shsj { get; set; }
        public string Shyc { get; set; }
        public sbyte? Shzt { get; set; }
    }
}
