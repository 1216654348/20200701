﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class HpfNbNdbgztz
    {
        public string Id { get; set; }
        public string Ndbgid { get; set; }
        public string Bm { get; set; }
        public string Nf { get; set; }
        public string Lxid { get; set; }
        public int? Ztz { get; set; }
        public DateTime? Rksj { get; set; }
    }
}
