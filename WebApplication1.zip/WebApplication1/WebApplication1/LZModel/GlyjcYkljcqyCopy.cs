﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcYkljcqyCopy
    {
        public string Id { get; set; }
        public string Mc { get; set; }
        public string Lx { get; set; }
        public string Ssjd { get; set; }
        public string Wzms { get; set; }
        public string Fw { get; set; }
        public int? Ryklxxz { get; set; }
        public int? Ssyklxzz { get; set; }
        public string Cjrid { get; set; }
        public DateTime? Cjsj { get; set; }
        public string Shrid { get; set; }
        public DateTime? Shsj { get; set; }
        public sbyte? Shzt { get; set; }
        public sbyte? Sfkdj { get; set; }
        public string Djrid { get; set; }
        public DateTime? Djsj { get; set; }
        public sbyte? Sfydj { get; set; }
        public string Shyc { get; set; }
        public DateTime? Tjsj { get; set; }
        public string Ssjdmc { get; set; }
        public string Rwid { get; set; }
        public string Jd { get; set; }
        public string Wd { get; set; }
    }
}
