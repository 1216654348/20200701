﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcRcxcyctj
    {
        public string Id { get; set; }
        public double? Year { get; set; }
        public double? Xxl { get; set; }
        public double? Zcsl { get; set; }
        public double? Ycsl { get; set; }
    }
}
