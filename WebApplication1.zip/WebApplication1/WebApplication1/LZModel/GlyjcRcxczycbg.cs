﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcRcxczycbg
    {
        public string Id { get; set; }
        public string Qyid { get; set; }
        public string Xcdd { get; set; }
        public string Ms { get; set; }
        public DateTime? Kssj { get; set; }
        public DateTime? Jssj { get; set; }
        public string Xcyid { get; set; }
        public string Xcymc { get; set; }
        public string Wdfj { get; set; }
        public string Cjrid { get; set; }
        public DateTime? Cjsj { get; set; }
        public string Shrid { get; set; }
        public DateTime? Shsj { get; set; }
        public string Shyc { get; set; }
        public sbyte? Shzt { get; set; }
    }
}
