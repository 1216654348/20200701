﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcRcxczycbgscjl
    {
        public string Id { get; set; }
        public string Jcpzid { get; set; }
        public DateTime? Scscsj { get; set; }
    }
}
