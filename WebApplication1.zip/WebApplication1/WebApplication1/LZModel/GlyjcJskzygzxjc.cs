﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcJskzygzxjc
    {
        public string Id { get; set; }
        public string Jzt { get; set; }
        public string Dbt { get; set; }
        public string Ms { get; set; }
        public string Pg { get; set; }
        public string Sjfw { get; set; }
        public string Bz { get; set; }
        public string Cjrid { get; set; }
        public DateTime? Cjsj { get; set; }
        public string Shrid { get; set; }
        public DateTime? Shsj { get; set; }
        public sbyte? Shzt { get; set; }
        public string Shbtgsm { get; set; }
        public string Djrid { get; set; }
        public DateTime? Djsj { get; set; }
        public sbyte? Sfydj { get; set; }
        public string Shyc { get; set; }
        public sbyte? Sfkdj { get; set; }
    }
}
