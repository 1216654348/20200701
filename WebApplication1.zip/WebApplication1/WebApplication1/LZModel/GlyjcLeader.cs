﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcLeader
    {
        public string Id { get; set; }
        public string Yjxxid { get; set; }
        public string Userid { get; set; }
        public string Yj { get; set; }
        public DateTime? Time { get; set; }
    }
}
