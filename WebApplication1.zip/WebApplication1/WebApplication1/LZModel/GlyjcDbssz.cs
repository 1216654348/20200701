﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcDbssz
    {
        public string Id { get; set; }
        public string Jcdid { get; set; }
        public DateTime? Jcsj { get; set; }
        public double? Ph { get; set; }
        public double? Ddl { get; set; }
        public double? Zd { get; set; }
        public double? Rjy { get; set; }
        public DateTime? Cjsj { get; set; }
        public string Cjrid { get; set; }
        public sbyte? Shzt { get; set; }
        public string Shrid { get; set; }
        public DateTime? Shsj { get; set; }
        public string Shyc { get; set; }
        public DateTime? Djsj { get; set; }
        public sbyte? Sfydj { get; set; }
        public string Djrid { get; set; }
    }
}
