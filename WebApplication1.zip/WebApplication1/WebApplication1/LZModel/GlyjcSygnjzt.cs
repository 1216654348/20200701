﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcSygnjzt
    {
        public string Id { get; set; }
        public string Sygnjzturl { get; set; }
        public string Cjrid { get; set; }
        public DateTime? Cjsj { get; set; }
        public string Shrid { get; set; }
        public DateTime? Shsj { get; set; }
        public sbyte? Shzt { get; set; }
        public string Shbtgsm { get; set; }
        public sbyte? Sfkdj { get; set; }
        public string Djrid { get; set; }
        public DateTime? Djsj { get; set; }
        public sbyte? Sfydj { get; set; }
        public string Shyc { get; set; }
        public DateTime? Tjsj { get; set; }
        public string OnlyId { get; set; }
        public string Code { get; set; }
        public string NameCn { get; set; }
        public string FuncPrest { get; set; }
        public string Health { get; set; }
        public string Pg { get; set; }
        public string Qksm { get; set; }
        public string Rwid { get; set; }
        public string Ywid { get; set; }
        public DateTime? Bhsj { get; set; }
        public string Jzt { get; set; }
        public string Dbt { get; set; }
    }
}
