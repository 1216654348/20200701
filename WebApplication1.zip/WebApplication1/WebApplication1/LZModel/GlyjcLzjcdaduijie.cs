﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcLzjcdaduijie
    {
        public string Id { get; set; }
        public string Djx { get; set; }
        public string Bmc { get; set; }
        public string Fjzd { get; set; }
        public int? Bid { get; set; }
        public DateTime? Sjdjsj { get; set; }
        public string Sfdj { get; set; }
    }
}
