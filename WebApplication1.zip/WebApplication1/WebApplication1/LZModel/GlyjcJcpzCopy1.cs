﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcJcpzCopy1
    {
        public string Id { get; set; }
        public string Cjrid { get; set; }
        public DateTime? Cjsj { get; set; }
        public string Shyc { get; set; }
        public DateTime? Tjsj { get; set; }
        public string Jcpzfamc { get; set; }
        public string Zt { get; set; }
        public string Jcx { get; set; }
        public string Jcpzysjid { get; set; }
        public string Ycysid { get; set; }
        public string Jcdxbid { get; set; }
        public string Jcdxid { get; set; }
        public string Jcwzbid { get; set; }
        public string Jcwzid { get; set; }
        public string Jcwzdtxxbid { get; set; }
        public string Lrfs { get; set; }
        public string Sjcjfzrbmid { get; set; }
        public string Sjcjfzrid { get; set; }
        public string Jcsjksyfw { get; set; }
        public string Ssjg { get; set; }
        public string Jcjlbcdd { get; set; }
        public string Jcjlbcsj { get; set; }
        public DateTime? Jcqssj { get; set; }
        public DateTime? Jcjssj { get; set; }
        public string Sfszqxjc { get; set; }
        public string Zq { get; set; }
        public string Zqdw { get; set; }
        public string Ds { get; set; }
        public int? Sc { get; set; }
        public string Yjxq { get; set; }
        public string Bz { get; set; }
        public string Sbids { get; set; }
    }
}
