﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class HpfNbZrzhjcqk
    {
        public string Id { get; set; }
        public string Ndbgid { get; set; }
        public DateTime? Cjsj { get; set; }
        public string Zhsjvalue { get; set; }
        public string Zhlxvalue { get; set; }
        public string Szqkmsvalue { get; set; }
        public string Zqyfcsvalue { get; set; }
        public decimal? Jzjevalue { get; set; }
        public DateTime? Rksj { get; set; }
        public int? Sort { get; set; }
        public int? Wzxs { get; set; }
        public sbyte? Isavailable { get; set; }
    }
}
