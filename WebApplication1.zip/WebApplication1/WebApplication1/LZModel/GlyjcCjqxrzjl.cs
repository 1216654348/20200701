﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcCjqxrzjl
    {
        public string Id { get; set; }
        public string Cjrid { get; set; }
        public DateTime? Cjsj { get; set; }
        public string Zxlb { get; set; }
        public string Zxnr { get; set; }
        public string Yssjid { get; set; }
        public string Bid { get; set; }
    }
}
