﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcRcxcqdjlb
    {
        public string Id { get; set; }
        public DateTime? Rwkssj { get; set; }
        public DateTime? Rwjssj { get; set; }
        public string Rwid { get; set; }
        public string Xgdglid { get; set; }
        public DateTime? Cjsj { get; set; }
        public double? Jd { get; set; }
        public double? Wd { get; set; }
    }
}
