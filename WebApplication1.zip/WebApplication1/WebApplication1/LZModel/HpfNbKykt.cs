﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class HpfNbKykt
    {
        public string Id { get; set; }
        public string Ndbgid { get; set; }
        public DateTime? Cjsj { get; set; }
        public string Ktmcvalue { get; set; }
        public string Ktfzrvalue { get; set; }
        public string Zyyjnrvalue { get; set; }
        public string Ktztvalue { get; set; }
        public string Kssjvalue { get; set; }
        public string Jxsjvalue { get; set; }
        public string Wtdwvalue { get; set; }
        public DateTime? Rksj { get; set; }
        public int? Sort { get; set; }
        public int? Wzxs { get; set; }
    }
}
