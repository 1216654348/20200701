﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcJrjglx
    {
        public string Id { get; set; }
        public string Yclx { get; set; }
        public string Ycnr { get; set; }
        public string Jyfa { get; set; }
        public DateTime? Cjsj { get; set; }
        public string Cjrid { get; set; }
    }
}
