﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcStyycystjxzpjjl
    {
        public string Id { get; set; }
        public string Lkxid { get; set; }
        public string Xczp { get; set; }
        public string Xzsffsbd { get; set; }
        public string Bdlx { get; set; }
        public string Bdqkms { get; set; }
        public string Bdyxcd { get; set; }
        public string Xmmc { get; set; }
        public string Bz { get; set; }
        public string Cjrid { get; set; }
        public DateTime? Cjsj { get; set; }
        public string Shrid { get; set; }
        public DateTime? Shsj { get; set; }
        public sbyte? Shzt { get; set; }
        public string Shbtgsm { get; set; }
        public string Djrid { get; set; }
        public DateTime? Djsj { get; set; }
        public sbyte? Sfydj { get; set; }
        public string Tjrid { get; set; }
        public string Shyc { get; set; }
        public DateTime? Tjsj { get; set; }
        public sbyte? Sfkdj { get; set; }
        public string Rwid { get; set; }
    }
}
