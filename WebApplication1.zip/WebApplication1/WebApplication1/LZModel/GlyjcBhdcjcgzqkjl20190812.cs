﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcBhdcjcgzqkjl20190812
    {
        public string Id { get; set; }
        public string Bhbh { get; set; }
        public string Bhwz { get; set; }
        public double? Bhjd { get; set; }
        public double? Bhwd { get; set; }
        public string Bhsyt { get; set; }
        public string Bhczzt { get; set; }
        public string Bhlx { get; set; }
        public string Bhztt { get; set; }
        public DateTime? Jcqssj { get; set; }
        public DateTime? Jcjssj { get; set; }
        public string Jcff { get; set; }
        public string Sjcjdbh { get; set; }
        public string Jczq { get; set; }
        public string Ssjg { get; set; }
        public string Jcsjksyfw { get; set; }
        public string Jcjlbcdd { get; set; }
        public string Jcjlbcsj { get; set; }
        public string Cjrid { get; set; }
        public DateTime? Cjsj { get; set; }
        public string Shrid { get; set; }
        public DateTime? Shsj { get; set; }
        public sbyte? Shzt { get; set; }
        public string Shbtgsm { get; set; }
        public sbyte? Sfkdj { get; set; }
        public string Djrid { get; set; }
        public DateTime? Djsj { get; set; }
        public sbyte? Sfydj { get; set; }
        public string Bbh { get; set; }
        public string Shyc { get; set; }
        public DateTime? Tjsj { get; set; }
        public string Onlyid { get; set; }
        public string Bhqywz { get; set; }
        public string Tcmc { get; set; }
        public DateTime? Xfsj { get; set; }
        public string Bhbha { get; set; }
        public string Ycysid { get; set; }
        public string Sfsb { get; set; }
        public double? Bhgd { get; set; }
        public string Dtlx { get; set; }
        public string Rwid { get; set; }
        public string Mj { get; set; }
    }
}
