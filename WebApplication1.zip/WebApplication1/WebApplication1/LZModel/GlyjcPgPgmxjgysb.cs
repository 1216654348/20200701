﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcPgPgmxjgysb
    {
        public string Id { get; set; }
        public string Ysjgmc { get; set; }
        public DateTime? Cjsj { get; set; }
        public string Mxid { get; set; }
    }
}
