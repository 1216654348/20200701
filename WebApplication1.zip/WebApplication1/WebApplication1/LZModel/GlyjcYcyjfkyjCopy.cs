﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcYcyjfkyjCopy
    {
        public string Id { get; set; }
        public string Pid { get; set; }
        public string Bid { get; set; }
        public string Fkr { get; set; }
        public string Dw { get; set; }
        public string Yj { get; set; }
        public string Fkwj { get; set; }
        public string Cjrid { get; set; }
        public DateTime? Cjsj { get; set; }
        public string Shrid { get; set; }
        public DateTime? Shsj { get; set; }
        public string Shyc { get; set; }
        public sbyte? Shzt { get; set; }
        public string Jlr { get; set; }
        public DateTime? Jlsj { get; set; }
    }
}
