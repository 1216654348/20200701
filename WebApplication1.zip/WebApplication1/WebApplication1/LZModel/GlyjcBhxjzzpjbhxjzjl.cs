﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcBhxjzzpjbhxjzjl
    {
        public string Id { get; set; }
        public string Cjrid { get; set; }
        public DateTime? Cjsj { get; set; }
        public string Shrid { get; set; }
        public DateTime? Shsj { get; set; }
        public sbyte? Shzt { get; set; }
        public string Shbtgsm { get; set; }
        public sbyte? Sfkdj { get; set; }
        public string Djrid { get; set; }
        public DateTime? Djsj { get; set; }
        public sbyte? Sfydj { get; set; }
        public string Shyc { get; set; }
        public DateTime? Tjsj { get; set; }
        public string Jzmc { get; set; }
        public double? Jzgd { get; set; }
        public int? Jzcs { get; set; }
        public int? Zdmj { get; set; }
        public string Jzjg { get; set; }
        public string Jgnd { get; set; }
        public string Jzwx { get; set; }
        public string Qtys { get; set; }
        public string Wdys { get; set; }
        public string Jzcqr { get; set; }
        public string Jzyt { get; set; }
        public string Bhxysms { get; set; }
        public sbyte? Xzsffsbd { get; set; }
        public string Fsbd { get; set; }
        public string Pg { get; set; }
        public string Zplj { get; set; }
        public string Zpmc { get; set; }
        public string Bz { get; set; }
        public string Txr { get; set; }
        public DateTime? Txrq { get; set; }
        public string Rwid { get; set; }
    }
}
