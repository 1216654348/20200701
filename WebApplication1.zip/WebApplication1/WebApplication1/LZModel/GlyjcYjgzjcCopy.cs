﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcYjgzjcCopy
    {
        public string Id { get; set; }
        public string Yjxxid { get; set; }
        public string Fkbm { get; set; }
        public string Xcy { get; set; }
        public DateTime? Xcsj { get; set; }
        public string Xcjgms { get; set; }
        public string Xczp { get; set; }
        public DateTime? Cjsj { get; set; }
        public string Cjrid { get; set; }
        public string Shrid { get; set; }
        public DateTime? Shsj { get; set; }
        public sbyte? Shzt { get; set; }
        public string Shbtgsm { get; set; }
        public string Shyc { get; set; }
    }
}
