﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class HpfNbYcqhcqshhjndjcjl
    {
        public string Id { get; set; }
        public string Ndbgid { get; set; }
        public DateTime? Cjsj { get; set; }
        public int? Zykcdslvalue { get; set; }
        public int? Fmyxfwvalue { get; set; }
        public int? Yzwrgyqyslvalue { get; set; }
        public int? Lrmlsdycqrkslvalue { get; set; }
        public int? Dqdycqrkslvalue { get; set; }
        public string Rkssxqvalue { get; set; }
        public int? Lrmlsdhcqrkvalue { get; set; }
        public int? Dqdhcqrkslvalue { get; set; }
        public DateTime? Rksj { get; set; }
        public int? Sort { get; set; }
        public int? Wzxs { get; set; }
    }
}
