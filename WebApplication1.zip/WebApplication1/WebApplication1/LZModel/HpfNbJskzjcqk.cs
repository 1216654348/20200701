﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class HpfNbJskzjcqk
    {
        public string Id { get; set; }
        public string Ndbgid { get; set; }
        public DateTime? Cjsj { get; set; }
        public string Xmmcvalue { get; set; }
        public string Jsmdvalue { get; set; }
        public string Jsddvalue { get; set; }
        public string Pzsjvalue { get; set; }
        public string Kgsjvalue { get; set; }
        public string Jgsjvalue { get; set; }
        public string Wwbmpzwhvalue { get; set; }
        public string Qtbmpzwhvalue { get; set; }
        public decimal? Zdmjvalue { get; set; }
        public string Dycdyxpgvalue { get; set; }
        public DateTime? Rksj { get; set; }
        public int? Sort { get; set; }
        public int? Wzxs { get; set; }
        public sbyte? Isavailable { get; set; }
    }
}
