﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcMjzb
    {
        public string BmcZw { get; set; }
        public string BmcYw { get; set; }
        public string ZdZw { get; set; }
        public string ZdYw { get; set; }
        public string Bm { get; set; }
        public string Mjx { get; set; }
        public string Pxbm { get; set; }
    }
}
