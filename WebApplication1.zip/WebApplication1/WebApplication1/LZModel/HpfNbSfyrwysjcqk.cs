﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class HpfNbSfyrwysjcqk
    {
        public string Id { get; set; }
        public string Ndbgid { get; set; }
        public string Cjsj { get; set; }
        public string Sfyrwysjcvalue { get; set; }
        public int? Sort { get; set; }
        public string Funiditem { get; set; }
        public int? Wzxs { get; set; }
        public DateTime? Rksj { get; set; }
    }
}
