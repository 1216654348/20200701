﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcSblxyjcdbdygx
    {
        public string Id { get; set; }
        public string Sblxid { get; set; }
        public string Jcdbid { get; set; }
        public string Jcsjbid { get; set; }
    }
}
