﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class HpfNbKyktXslw
    {
        public string Id { get; set; }
        public string Ndbgid { get; set; }
        public DateTime? Cjsj { get; set; }
        public string Lwmcvalue { get; set; }
        public string Zzvalue { get; set; }
        public string Sjmcvalue { get; set; }
        public string Sjlxvalue { get; set; }
        public string Qhvalue { get; set; }
        public int? Sort { get; set; }
        public int? Wzxs { get; set; }
        public DateTime? Rksj { get; set; }
    }
}
