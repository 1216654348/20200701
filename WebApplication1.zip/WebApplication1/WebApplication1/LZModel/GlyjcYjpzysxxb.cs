﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcYjpzysxxb
    {
        public string Id { get; set; }
        public string Cjrid { get; set; }
        public DateTime? Cjsj { get; set; }
        public string Jcx { get; set; }
        public string BmcZw { get; set; }
        public string BmcYw { get; set; }
        public string YjzdZw { get; set; }
        public string YjzdYw { get; set; }
        public string Yjzdlx { get; set; }
        public string Dw { get; set; }
        public string Jcdx { get; set; }
        public string Lx { get; set; }
        public string Dyzd { get; set; }
        public string Sbid { get; set; }
        public string Paraid { get; set; }
    }
}
