﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class HepengTempDtzb
    {
        public string Id { get; set; }
        public double? Dtjd { get; set; }
        public double? Dtwd { get; set; }
        public double? Cjdjd { get; set; }
        public double? Cjdwd { get; set; }
    }
}
