﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcPgPgmx
    {
        public string Id { get; set; }
        public string Mxmc { get; set; }
        public string Dlid { get; set; }
        public DateTime? Cjsj { get; set; }
        public string Pgszyzdw { get; set; }
    }
}
