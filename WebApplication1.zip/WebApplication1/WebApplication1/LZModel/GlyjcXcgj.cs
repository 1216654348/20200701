﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcXcgj
    {
        public string Id { get; set; }
        public string Ryid { get; set; }
        public DateTime? Xcrq { get; set; }
        public decimal? Jd { get; set; }
        public decimal? Wd { get; set; }
    }
}
