﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcYcqhhcqshhjndjcjl
    {
        public string Id { get; set; }
        public string Cjrid { get; set; }
        public DateTime? Cjsj { get; set; }
        public string Shrid { get; set; }
        public DateTime? Shsj { get; set; }
        public sbyte? Shzt { get; set; }
        public string Shbtgsm { get; set; }
        public sbyte? Sfkdj { get; set; }
        public string Shyc { get; set; }
        public DateTime? Djsj { get; set; }
        public sbyte? Sfydj { get; set; }
        public string Tjrid { get; set; }
        public DateTime? Tjsj { get; set; }
        public int? Zykcdsl { get; set; }
        public int? Yzwrgyqysl { get; set; }
        public int? Lrmlsdycqrksl { get; set; }
        public int? Dqdycqrksl { get; set; }
        public string Rkssxq { get; set; }
        public int? Lrmlsdhcqrk { get; set; }
        public int? Dqdhcqrksl { get; set; }
        public string Ycqrkmdsyd { get; set; }
        public int? Fmyxfw { get; set; }
        public string Rwid { get; set; }
        public string Nd { get; set; }
        public string Djrid { get; set; }
        public double? Nyzz { get; set; }
        public double? Gyzz { get; set; }
        public double? Fwyzz { get; set; }
        public string Sdcybl { get; set; }
        public int? Dqdhcqjmhs { get; set; }
        public int? Dqdycqjmhs { get; set; }
    }
}
