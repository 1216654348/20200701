﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class HpfNbJcjgqk
    {
        public string Id { get; set; }
        public string Ndbgid { get; set; }
        public string Jcjgmcvalue { get; set; }
        public string Sfwdljzvalue { get; set; }
        public string Cddzrvalue { get; set; }
        public string Fzrvalue { get; set; }
        public string Fzrlxdhvalue { get; set; }
        public string Lxrvalue { get; set; }
        public string Lxdhvalue { get; set; }
        public string Dzyxvalue { get; set; }
        public string Jcgzwzvalue { get; set; }
        public string Sjgldwvalue { get; set; }
        public string Jgclsjvalue { get; set; }
        public string Jgjbvalue { get; set; }
        public int? Ryzsvalue { get; set; }
        public DateTime? Rksj { get; set; }
        public DateTime? Cjsj { get; set; }
        public int? Sort { get; set; }
        public int? Wzxs { get; set; }
        public sbyte? Isavailable { get; set; }
    }
}
