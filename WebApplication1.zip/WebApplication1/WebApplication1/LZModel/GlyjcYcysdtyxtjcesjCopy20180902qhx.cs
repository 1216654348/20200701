﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcYcysdtyxtjcesjCopy20180902qhx
    {
        public string Id { get; set; }
        public string Ysdtid { get; set; }
        public string Pg { get; set; }
        public string Qksm { get; set; }
        public DateTime? Jcsj { get; set; }
        public string Yszplj { get; set; }
        public string Ycysbczt { get; set; }
        public string Rwid { get; set; }
        public string Cjrid { get; set; }
        public DateTime? Cjsj { get; set; }
        public string Shrid { get; set; }
        public DateTime? Shsj { get; set; }
        public sbyte? Shzt { get; set; }
        public string Shbtgsm { get; set; }
        public sbyte? Sfkdj { get; set; }
        public string Djrid { get; set; }
        public DateTime? Djsj { get; set; }
        public sbyte? Sfydj { get; set; }
        public string Shyc { get; set; }
        public DateTime? Tjsj { get; set; }
        public string Bizid { get; set; }
        public string Leftbottom { get; set; }
        public string Righttop { get; set; }
        public string Geos { get; set; }
        public string Tjrid { get; set; }
        public string Bhms { get; set; }
    }
}
