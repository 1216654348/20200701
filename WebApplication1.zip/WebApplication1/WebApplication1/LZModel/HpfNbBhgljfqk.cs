﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class HpfNbBhgljfqk
    {
        public string Id { get; set; }
        public string Ndbgid { get; set; }
        public decimal? Bhglzjfvalue { get; set; }
        public decimal? Jcglvalue { get; set; }
        public decimal? Bhxsvalue { get; set; }
        public decimal? Xsyjvalue { get; set; }
        public decimal? Lyglvalue { get; set; }
        public decimal? Xcjyvalue { get; set; }
        public decimal? Rykzvalue { get; set; }
        public decimal? Hjzzvalue { get; set; }
        public decimal? Qtvalue { get; set; }
        public DateTime? Rksj { get; set; }
        public DateTime? Cjsj { get; set; }
        public int? Sort { get; set; }
        public int? Wzxs { get; set; }
    }
}
