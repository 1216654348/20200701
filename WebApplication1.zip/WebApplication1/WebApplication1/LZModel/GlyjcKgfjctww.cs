﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcKgfjctww
    {
        public string Id { get; set; }
        public string Kgfjxmid { get; set; }
        public string Kgfjjlid { get; set; }
        public string Wwmc { get; set; }
        public string Wwms { get; set; }
        public string Wwzp { get; set; }
        public DateTime? Ctsj { get; set; }
    }
}
