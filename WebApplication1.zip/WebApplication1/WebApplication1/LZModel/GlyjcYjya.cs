﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcYjya
    {
        public string Id { get; set; }
        public string Cjrid { get; set; }
        public DateTime? Cjsj { get; set; }
        public string Shyc { get; set; }
        public DateTime? Tjsj { get; set; }
        public string Yamc { get; set; }
        public string Jcx { get; set; }
        public string Yawdfj { get; set; }
        public DateTime? Bxsj { get; set; }
        public string Bzsm { get; set; }
    }
}
