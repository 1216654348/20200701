﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcJcpzRwscsj
    {
        public string Id { get; set; }
        public string Jcpzid { get; set; }
        public DateTime? Scrwsj { get; set; }
    }
}
