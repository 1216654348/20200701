﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcPgPgzb
    {
        public string Id { get; set; }
        public string Zbmc { get; set; }
        public string Dlid { get; set; }
        public DateTime? Cjsj { get; set; }
    }
}
