﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcLsdljcjl
    {
        public string Id { get; set; }
        public string Cjrid { get; set; }
        public DateTime? Cjsj { get; set; }
        public string Shrid { get; set; }
        public DateTime? Shsj { get; set; }
        public sbyte? Shzt { get; set; }
        public string Shbtgsm { get; set; }
        public sbyte? Sfkdj { get; set; }
        public string Djrid { get; set; }
        public DateTime? Djsj { get; set; }
        public sbyte? Sfydj { get; set; }
        public string Shyc { get; set; }
        public DateTime? Tjsj { get; set; }
        public string Ldmc { get; set; }
        public string Szhx { get; set; }
        public string Szdl { get; set; }
        public string Wqcdbhqk { get; set; }
        public string Wqgdbhqk { get; set; }
        public double? Wqcd { get; set; }
        public double? Wqgd { get; set; }
        public string Wqwzbh { get; set; }
        public string Dlpz { get; set; }
        public string Qtys { get; set; }
        public string Qtcz { get; set; }
        public string Dlkdbhqk { get; set; }
        public string Wqydlgkb { get; set; }
        public string Pg { get; set; }
        public string Bz { get; set; }
        public string Dlzplj { get; set; }
        public string Dlzpmc { get; set; }
        public string Txr { get; set; }
        public DateTime? Txrq { get; set; }
        public string Zpmc { get; set; }
        public string Rwid { get; set; }
    }
}
