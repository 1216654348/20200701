﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcQnsw
    {
        public string Id { get; set; }
        public string Jcdid { get; set; }
        public string Nf { get; set; }
        public double? Pjz { get; set; }
        public DateTime? Rksj { get; set; }
    }
}
