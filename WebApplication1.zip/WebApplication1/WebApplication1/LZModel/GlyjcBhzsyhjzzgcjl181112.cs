﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcBhzsyhjzzgcjl181112
    {
        public string Id { get; set; }
        public string Xmmc { get; set; }
        public string Xmfl { get; set; }
        public string Gcfl { get; set; }
        public string Wwbmpz { get; set; }
        public int? Jftrze { get; set; }
        public int? Zyczjf { get; set; }
        public string Cjrid { get; set; }
        public DateTime? Cjsj { get; set; }
        public string Shrid { get; set; }
        public DateTime? Shsj { get; set; }
        public sbyte? Shzt { get; set; }
        public string Shbtgsm { get; set; }
        public sbyte? Sfkdj { get; set; }
        public string Djrid { get; set; }
        public DateTime? Djsj { get; set; }
        public sbyte? Sfydj { get; set; }
        public string Shyc { get; set; }
        public DateTime? Tjsj { get; set; }
        public DateTime? Kssj { get; set; }
        public DateTime? Jssj { get; set; }
        public string Bhzsyhjzzgcda { get; set; }
        public string Xmfwturl { get; set; }
        public string Onlyid { get; set; }
        public string Tjrid { get; set; }
        public string Sgdw { get; set; }
        public string Jldw { get; set; }
        public string Bhgcjzqk { get; set; }
        public int? Bhgcjfgjbz { get; set; }
        public int? Bhgcjfdfpt { get; set; }
        public DateTime? Gjwwjysrq { get; set; }
        public string Ejgcfl { get; set; }
        public DateTime? Jgysrq { get; set; }
        public string Syt { get; set; }
        public string Xmfw { get; set; }
        public double? Wd { get; set; }
        public double? Jd { get; set; }
        public string Rwid { get; set; }
    }
}
