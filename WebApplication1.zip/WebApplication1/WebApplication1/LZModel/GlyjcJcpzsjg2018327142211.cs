﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcJcpzsjg2018327142211
    {
        public string Id { get; set; }
        public string Fid { get; set; }
        public string Pid { get; set; }
        public string Mc { get; set; }
        public string Jcpzysjid { get; set; }
        public int? Px { get; set; }
    }
}
