﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcPgDllb
    {
        public string Id { get; set; }
        public string Dlmc { get; set; }
        public DateTime? Cjsj { get; set; }
    }
}
