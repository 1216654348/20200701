﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcTfszjl
    {
        public string Id { get; set; }
        public string Cxsj { get; set; }
        public DateTime? Jcsj { get; set; }
        public string Tfdj { get; set; }
        public string Pg { get; set; }
        public string Cjrid { get; set; }
        public DateTime? Cjsj { get; set; }
        public string Shrid { get; set; }
        public DateTime? Shsj { get; set; }
        public sbyte? Shzt { get; set; }
        public string Shbtgsm { get; set; }
        public string Djrid { get; set; }
        public DateTime? Djsj { get; set; }
        public sbyte? Sfydj { get; set; }
        public string Tjrid { get; set; }
        public string Shyc { get; set; }
        public DateTime? Tjsj { get; set; }
        public sbyte? Sfkdj { get; set; }
    }
}
