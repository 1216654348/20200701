﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcPgztjl
    {
        public string Id { get; set; }
        public string Bhid { get; set; }
        public string Ycysid { get; set; }
        public string Pg { get; set; }
        public DateTime? Cjsj { get; set; }
    }
}
