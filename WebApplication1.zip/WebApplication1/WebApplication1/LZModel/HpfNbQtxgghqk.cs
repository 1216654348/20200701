﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class HpfNbQtxgghqk
    {
        public string Id { get; set; }
        public string Ndbgid { get; set; }
        public string Cjrid { get; set; }
        public DateTime? Cjsj { get; set; }
        public string Mcvalue { get; set; }
        public string Lxvalue { get; set; }
        public string Ghqxvalue { get; set; }
        public string Bzhgbztvalue { get; set; }
        public string Bzdwvalue { get; set; }
        public DateTime? Rksj { get; set; }
        public int? Sort { get; set; }
        public int? Wzxs { get; set; }
        public sbyte? Isavailable { get; set; }
    }
}
