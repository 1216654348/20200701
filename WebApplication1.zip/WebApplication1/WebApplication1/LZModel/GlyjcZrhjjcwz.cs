﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcZrhjjcwz
    {
        public string Id { get; set; }
        public string Zbsjid { get; set; }
        public string Zcdxlx { get; set; }
        public string Jcwzmc { get; set; }
        public string Jcwzsyt { get; set; }
        public string Zb { get; set; }
        public string Jcwzms { get; set; }
        public int? Px { get; set; }
    }
}
