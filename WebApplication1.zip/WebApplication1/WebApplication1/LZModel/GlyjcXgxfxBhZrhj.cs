﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcXgxfxBhZrhj
    {
        public string Id { get; set; }
        public string Bhqdid { get; set; }
        public string Zrhjqdid { get; set; }
        public DateTime? Cjsj { get; set; }
    }
}
