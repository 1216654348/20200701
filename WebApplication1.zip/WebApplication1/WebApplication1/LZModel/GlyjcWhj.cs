﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcWhj
    {
        public string Id { get; set; }
        public DateTime? Jcsj { get; set; }
        public double? Fs { get; set; }
        public double? Dqwd { get; set; }
        public double? Dqsd { get; set; }
        public double? Fx { get; set; }
        public string Jcdid { get; set; }
        public DateTime? Cjsj { get; set; }
        public DateTime? Shsj { get; set; }
        public int? Shzt { get; set; }
        public string Shyc { get; set; }
        public sbyte? Sfydj { get; set; }
        public DateTime? Djsj { get; set; }
        public string Djrid { get; set; }
    }
}
