﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcPgPgsz
    {
        public string Id { get; set; }
        public string Mxid { get; set; }
        public string Ysjgid { get; set; }
        public double? Yzxz { get; set; }
        public double? Yzdz { get; set; }
    }
}
