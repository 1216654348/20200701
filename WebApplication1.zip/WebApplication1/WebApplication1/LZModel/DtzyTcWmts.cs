﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class DtzyTcWmts
    {
        public string Id { get; set; }
        public string Mc { get; set; }
        public string Bm { get; set; }
        public string Url { get; set; }
        public string Ztcj { get; set; }
        public string Zzfs { get; set; }
        public string Bz { get; set; }
        public string Zbck { get; set; }
        public string Tl { get; set; }
    }
}
