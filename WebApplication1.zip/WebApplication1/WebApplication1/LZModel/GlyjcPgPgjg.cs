﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcPgPgjg
    {
        public string Id { get; set; }
        public string Pgjlid { get; set; }
        public string Pgjg { get; set; }
        public string Pgbg { get; set; }
        public DateTime? Cjsj { get; set; }
        public string Zbsjjgbid { get; set; }
        public string Zbsjjgid { get; set; }
    }
}
