﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcPgXzyssjb
    {
        public string Id { get; set; }
        public string Pgjlid { get; set; }
        public string Mc { get; set; }
        public string Cclj { get; set; }
        public DateTime? Cjsj { get; set; }
    }
}
