﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcSjztjl
    {
        public string Id { get; set; }
        public string Bid { get; set; }
        public string Sjid { get; set; }
        public string Cjrid { get; set; }
        public DateTime? Cjsj { get; set; }
        public string Shrid { get; set; }
        public string Shyc { get; set; }
        public string Shzt { get; set; }
        public DateTime? Shsj { get; set; }
        public string Rwid { get; set; }
    }
}
