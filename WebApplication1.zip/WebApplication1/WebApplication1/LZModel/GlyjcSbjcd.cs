﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcSbjcd
    {
        public string Id { get; set; }
        public string Sbid { get; set; }
        public string Jcdmc { get; set; }
        public string Wzms { get; set; }
        public string Dtlx { get; set; }
        public string Dtid { get; set; }
        public string Zb { get; set; }
        public double? X { get; set; }
        public double? Y { get; set; }
        public double? Z { get; set; }
    }
}
