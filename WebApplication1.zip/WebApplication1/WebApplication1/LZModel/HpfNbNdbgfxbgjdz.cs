﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class HpfNbNdbgfxbgjdz
    {
        public string Id { get; set; }
        public string Bm { get; set; }
        public string Ndbgid { get; set; }
        public int? Lx { get; set; }
        public int? Typeonejdz { get; set; }
        public int? Typetwojdz { get; set; }
        public int? Typethreejdz { get; set; }
        public int? Typeforejdz { get; set; }
        public string Nf { get; set; }
        public DateTime? Rksj { get; set; }
        public string Typeonejdx { get; set; }
        public string Typetwojdx { get; set; }
        public string Typethreejdx { get; set; }
        public string Typeforejdx { get; set; }
    }
}
