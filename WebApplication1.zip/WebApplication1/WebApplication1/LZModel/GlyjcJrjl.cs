﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcJrjl
    {
        public string Id { get; set; }
        public string Jcpzfaid { get; set; }
        public string Jcdid { get; set; }
        public sbyte? Jrzt { get; set; }
        public DateTime? Jrsj { get; set; }
        public DateTime? Jrkssj { get; set; }
        public DateTime? Jrjssj { get; set; }
    }
}
