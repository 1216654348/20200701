﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcShrzb
    {
        public string BmcYw { get; set; }
        public string Sjzjid { get; set; }
        public string Shrz { get; set; }
        public DateTime? Cjsj { get; set; }
        public string Id { get; set; }
    }
}
