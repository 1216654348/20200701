﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class HpfNbAxfxtyjssxx
    {
        public string Id { get; set; }
        public string Ndbgid { get; set; }
        public DateTime? Cjsj { get; set; }
        public decimal? Jftrzevalue { get; set; }
        public decimal? Zyczjfvalue { get; set; }
        public string Axfxtnrvalue { get; set; }
        public string Jcsjvalue { get; set; }
        public DateTime? Rksj { get; set; }
        public int? Sort { get; set; }
        public int? Wzxs { get; set; }
    }
}
