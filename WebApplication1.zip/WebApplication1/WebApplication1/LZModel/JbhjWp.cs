﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class JbhjWp
    {
        public string Id { get; set; }
        public string Jcz { get; set; }
    }
}
