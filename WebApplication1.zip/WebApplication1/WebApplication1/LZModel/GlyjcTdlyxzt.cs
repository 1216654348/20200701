﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcTdlyxzt
    {
        public string Id { get; set; }
        public string Cjrid { get; set; }
        public DateTime? Cjsj { get; set; }
        public string Shrid { get; set; }
        public DateTime? Shsj { get; set; }
        public int? Shzt { get; set; }
        public string Shbtgsm { get; set; }
        public sbyte? Sfkdj { get; set; }
        public string Djrid { get; set; }
        public DateTime? Djsj { get; set; }
        public sbyte? Sfydj { get; set; }
        public string Shyc { get; set; }
        public DateTime? Tjsj { get; set; }
        public string Tdlyxzturl { get; set; }
        public string Tdlyxz { get; set; }
        public string Onlyid { get; set; }
        public string Mc { get; set; }
        public string Ydlx { get; set; }
        public string Bizid { get; set; }
        public string Rwid { get; set; }
        public string Nd { get; set; }
        public double? Area { get; set; }
    }
}
