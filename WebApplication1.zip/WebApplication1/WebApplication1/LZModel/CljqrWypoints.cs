﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class CljqrWypoints
    {
        public string Id { get; set; }
        public string Pot { get; set; }
        public string Pic { get; set; }
        public string Potjc { get; set; }
    }
}
