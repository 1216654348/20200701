﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcJcpzysj
    {
        public string Id { get; set; }
        public string Ycysbid { get; set; }
        public string Ycyszd { get; set; }
        public string Ycysyjcdx { get; set; }
        public string Jcdxbid { get; set; }
        public string Jcdxzd { get; set; }
        public string Jcdxzbzd { get; set; }
        public string Jcdxlmzbzd { get; set; }
        public string Jcdxsytzd { get; set; }
        public string Jcwzbid { get; set; }
        public string Jcdxyjcwz { get; set; }
        public string Jcwzdtzd { get; set; }
        public string Bz { get; set; }
        public string Jcdxdtxxbid { get; set; }
        public string Jcwzdtxxbid { get; set; }
        public string Jcwzdtxxbmc { get; set; }
        public string Jcwzmsyjcdxmszd { get; set; }
        public string Yddcjsjbid { get; set; }
        public string Jcdxdtxxbmc { get; set; }
    }
}
