﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcZqwc
    {
        public string Id { get; set; }
        public int? Zqdw { get; set; }
        public int? Wc { get; set; }
    }
}
