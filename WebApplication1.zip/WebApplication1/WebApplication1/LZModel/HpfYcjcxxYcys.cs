﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class HpfYcjcxxYcys
    {
        public string Id { get; set; }
        public string Zcbfid { get; set; }
        public string Bm { get; set; }
        public string Mc { get; set; }
        public string Ycysms { get; set; }
        public string Ycyslx { get; set; }
        public string Gm { get; set; }
        public string Xxwz { get; set; }
        public string Fz { get; set; }
        public decimal? Jd { get; set; }
        public decimal? Wd { get; set; }
        public string Gc { get; set; }
        public string Sm { get; set; }
        public string Dbxtp { get; set; }
        public string Nd { get; set; }
        public string Cjrid { get; set; }
        public DateTime? Cjsj { get; set; }
        public string Tjrid { get; set; }
        public DateTime? Tjsj { get; set; }
        public string Shrid { get; set; }
        public string Shzt { get; set; }
        public DateTime? Shsj { get; set; }
        public string Djrid { get; set; }
        public DateTime? Djsj { get; set; }
        public string Shyc { get; set; }
        public DateTime? Rksj { get; set; }
        public string Dydwbdw { get; set; }
        public string Glycbtid { get; set; }
        public string Gmlx { get; set; }
        public string Shbtgsm { get; set; }
        public string Bz { get; set; }
        public int? Xh { get; set; }
        public string Fid { get; set; }
        public int? Lycs { get; set; }
        public string Yczcmc { get; set; }
        public string Yygs { get; set; }
    }
}
