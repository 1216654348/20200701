﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcSjjcxb
    {
        public string Id { get; set; }
        public string Jcpzysjid { get; set; }
        public string Lxzd { get; set; }
        public sbyte? Lx { get; set; }
        public sbyte? Cjfs { get; set; }
        public string Jcxid { get; set; }
        public string Jcxmc { get; set; }
        public string Yjzd { get; set; }
        public string Yjzdlx { get; set; }
        public string Dw { get; set; }
        public string Zpzd { get; set; }
    }
}
