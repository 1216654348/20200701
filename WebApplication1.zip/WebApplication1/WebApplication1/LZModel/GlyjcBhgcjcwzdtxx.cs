﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcBhgcjcwzdtxx
    {
        public string Id { get; set; }
        public string Sjid { get; set; }
        public string Lx { get; set; }
        public string Zbxx { get; set; }
    }
}
