﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcRcxcycjlCopy20200511
    {
        public string Id { get; set; }
        public string Cjrid { get; set; }
        public DateTime? Cjsj { get; set; }
        public string Shrid { get; set; }
        public DateTime? Shsj { get; set; }
        public sbyte? Shzt { get; set; }
        public string Shbtgsm { get; set; }
        public sbyte? Sfkdj { get; set; }
        public string Djrid { get; set; }
        public DateTime? Djsj { get; set; }
        public sbyte? Sfydj { get; set; }
        public string Shyc { get; set; }
        public string Tjrid { get; set; }
        public DateTime? Tjsj { get; set; }
        public string Ycjcrid { get; set; }
        public DateTime? Xcrq { get; set; }
        public string Ycsj { get; set; }
        public string Yczb { get; set; }
        public string Xcy { get; set; }
        public string Dscqdcs { get; set; }
        public string Rwid { get; set; }
        public string Zpmc { get; set; }
        public string Sfbj { get; set; }
        public string Ycysid { get; set; }
        public string Sjms { get; set; }
        public string Yclx { get; set; }
        public string Sjcjfs { get; set; }
        public string Jchzp { get; set; }
        public DateTime? Jcsj { get; set; }
        public string Ycsfjc { get; set; }
        public string Pg { get; set; }
        public string Fswzwz { get; set; }
        public double? Jd { get; set; }
        public double? Wd { get; set; }
        public string Rcxcjlid { get; set; }
        public string Xgjlid { get; set; }
        public string Qyid { get; set; }
        public string Bz { get; set; }
        public string Dycdyxcd { get; set; }
        public string Ysclzp { get; set; }
        public int? Sort { get; set; }
    }
}
