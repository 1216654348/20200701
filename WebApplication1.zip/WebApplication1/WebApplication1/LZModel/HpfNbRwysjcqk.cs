﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class HpfNbRwysjcqk
    {
        public string Id { get; set; }
        public string Ndbgid { get; set; }
        public DateTime? Cjsj { get; set; }
        public string Sjvalue { get; set; }
        public string Rwsjmsvalue { get; set; }
        public string Cqdcsvalue { get; set; }
        public decimal? Ssqkvalue { get; set; }
        public DateTime? Rksj { get; set; }
        public int? Sort { get; set; }
        public int? Wzxs { get; set; }
        public sbyte? Isavailable { get; set; }
    }
}
