﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcRcxcjlCopy20200511
    {
        public string Id { get; set; }
        public string Cjrid { get; set; }
        public DateTime? Cjsj { get; set; }
        public string Shrid { get; set; }
        public DateTime? Shsj { get; set; }
        public sbyte? Shzt { get; set; }
        public string Shbtgsm { get; set; }
        public sbyte? Sfkdj { get; set; }
        public string Djrid { get; set; }
        public DateTime? Djsj { get; set; }
        public sbyte? Sfydj { get; set; }
        public string Shyc { get; set; }
        public string Tjrid { get; set; }
        public DateTime? Tjsj { get; set; }
        public string Xcddycd { get; set; }
        public string Xcddwz { get; set; }
        public string Xcqkmsxclx { get; set; }
        public string Xcqkmsfsycqkms { get; set; }
        public string Bz { get; set; }
        public string Yczpmc { get; set; }
        public string Yczplj { get; set; }
        public string Xcy { get; set; }
        public DateTime? Xcsj { get; set; }
        public string Zpmc { get; set; }
        public string Rwid { get; set; }
        public string Sfyc { get; set; }
        public string Xgjlid { get; set; }
    }
}
