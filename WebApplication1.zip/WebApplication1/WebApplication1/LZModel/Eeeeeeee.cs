﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class Eeeeeeee
    {
        public string Mc { get; set; }
        public string Lx { get; set; }
        public string Lj { get; set; }
    }
}
