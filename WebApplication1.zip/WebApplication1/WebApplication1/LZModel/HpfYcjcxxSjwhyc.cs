﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class HpfYcjcxxSjwhyc
    {
        public string Id { get; set; }
        public string Bm { get; set; }
        public string Ycmc { get; set; }
        public string Ywmc { get; set; }
        public string Yclx { get; set; }
        public string Ycgk { get; set; }
        public string Ywycgk { get; set; }
        public string Rxbz { get; set; }
        public int? Rxnf { get; set; }
        public string Gbwh { get; set; }
        public string Gbjg { get; set; }
        public string Xzqbm { get; set; }
        public decimal? Jd { get; set; }
        public decimal? Wd { get; set; }
        public string Kznf { get; set; }
        public string Ycpj { get; set; }
        public string Ycjz { get; set; }
        public string Dbzp { get; set; }
        public string Wzsm { get; set; }
        public string Zyycxzms { get; set; }
        public DateTime? Rksj { get; set; }
        public sbyte? Sfsjwhyc { get; set; }
        public string Ycqmj { get; set; }
        public string Hcqmj { get; set; }
        public ulong? Bfzc { get; set; }
        public int? Zssx { get; set; }
    }
}
