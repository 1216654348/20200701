﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcZjrwb
    {
        public string Id { get; set; }
        public string Rwzt { get; set; }
        public string Rwmc { get; set; }
        public string Rwyxjb { get; set; }
        public DateTime? Rwscsj { get; set; }
        public DateTime? Rwfhsj { get; set; }
        public string Rwcjr { get; set; }
        public string Ssbm { get; set; }
        public string Zjid { get; set; }
        public string Zjdwid { get; set; }
        public sbyte? Sfpg { get; set; }
        public string Jcxid { get; set; }
        public string Jcdx { get; set; }
        public string Jcnrid { get; set; }
        public string Jtbw { get; set; }
        public string Jcsb { get; set; }
        public DateTime? Jckssj { get; set; }
        public string Jczq { get; set; }
        public string Jcesjhzfj { get; set; }
        public string Yssjfj { get; set; }
        public string Qtxgfj { get; set; }
        public string Jljjyfj { get; set; }
        public string Jljjy { get; set; }
        public string Cjrid { get; set; }
        public DateTime? Cjsj { get; set; }
        public string Shrid { get; set; }
        public DateTime? Shsj { get; set; }
        public sbyte? Shzt { get; set; }
        public string Shbtgsm { get; set; }
        public sbyte? Sfkdj { get; set; }
        public string Djrid { get; set; }
        public DateTime? Djsj { get; set; }
        public sbyte? Sfydj { get; set; }
        public string Shyc { get; set; }
        public DateTime? Tjsj { get; set; }
    }
}
