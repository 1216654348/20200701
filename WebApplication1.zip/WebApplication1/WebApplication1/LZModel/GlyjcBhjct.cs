﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcBhjct
    {
        public string Id { get; set; }
        public string Ycysid { get; set; }
        public string Tcmc { get; set; }
        public string Zpmc { get; set; }
    }
}
