﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcPgZbdxglb
    {
        public string Id { get; set; }
        public string Zbid { get; set; }
        public string Pgdxid { get; set; }
        public string Zsdxmc { get; set; }
        public DateTime? Cjsj { get; set; }
        public string Zbsjjgbid { get; set; }
        public DateTime? Scjssj { get; set; }
        public string Dygslmc { get; set; }
        public DateTime? Sjzxsj { get; set; }
        public DateTime? Sjzdsj { get; set; }
    }
}
