﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcSlWdlBhdcjcgzqkjl
    {
        public string Id { get; set; }
        public string Bhid { get; set; }
        public string Sjly { get; set; }
        public string Rhw { get; set; }
        public DateTime? Scjysj { get; set; }
        public string Jssd { get; set; }
        public double? Slmj { get; set; }
        public string Slmjpg { get; set; }
        public int? Ssdge { get; set; }
        public string Ssdgepg { get; set; }
        public string Bz { get; set; }
        public string Dcr { get; set; }
        public DateTime? Dcsj { get; set; }
        public string Cjrid { get; set; }
        public DateTime? Cjsj { get; set; }
        public string Shrid { get; set; }
        public DateTime? Shsj { get; set; }
        public sbyte? Shzt { get; set; }
        public string Shbtgsm { get; set; }
        public sbyte? Sfkdj { get; set; }
        public string Djrid { get; set; }
        public DateTime? Djsj { get; set; }
        public sbyte? Sfydj { get; set; }
        public string Shyc { get; set; }
        public DateTime? Tjsj { get; set; }
        public string Rwid { get; set; }
        public string Zpmc { get; set; }
        public string Tjrid { get; set; }
        public string Jcwzid { get; set; }
        public string Bhbh { get; set; }
        public double? Bhjd { get; set; }
        public double? Bhwd { get; set; }
        public string Zbxx { get; set; }
        public string Cjrname { get; set; }
        public string Jcwzmc { get; set; }
    }
}
