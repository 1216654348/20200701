﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class HpfNbNdbgzb
    {
        public string Id { get; set; }
        public string Bm { get; set; }
        public string Mc { get; set; }
        public sbyte? Shzt { get; set; }
        public sbyte? Tjzt { get; set; }
        public string Nf { get; set; }
        public ulong? Iffc { get; set; }
        public string Lj { get; set; }
        public string Kzm { get; set; }
        public string Shyj { get; set; }
        public DateTime? Rksj { get; set; }
    }
}
