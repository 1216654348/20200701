﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcKgfjxm
    {
        public string Id { get; set; }
        public string Xmmc { get; set; }
        public string Pzwh { get; set; }
        public string Fjdw { get; set; }
        public double? Pzfjmj { get; set; }
        public double? Jftrze { get; set; }
        public string Kssj { get; set; }
        public string Jssj { get; set; }
        public string Zszp { get; set; }
        public DateTime? Cjsj { get; set; }
        public string Cjrid { get; set; }
        public string Shrid { get; set; }
        public DateTime? Shsj { get; set; }
        public string Shzt { get; set; }
        public string Shbtgsm { get; set; }
        public string Sfkdj { get; set; }
        public string Djrid { get; set; }
        public DateTime? Djsj { get; set; }
        public string Sfydj { get; set; }
        public string Shyc { get; set; }
    }
}
