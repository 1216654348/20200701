﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcPgPgjlb
    {
        public string Id { get; set; }
        public string Pgjlmc { get; set; }
        public string Pgjlsm { get; set; }
        public sbyte? Pgfs { get; set; }
        public string Pgdxid { get; set; }
        public string Pgmxid { get; set; }
        public string Zjid { get; set; }
        public DateTime? Pgqssj { get; set; }
        public DateTime? Pgjssj { get; set; }
        public sbyte? Zt { get; set; }
        public string Cjrid { get; set; }
        public DateTime? Cjsj { get; set; }
        public string Pgbgmb { get; set; }
    }
}
