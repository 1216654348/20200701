﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcPgXzfxsjb
    {
        public string Id { get; set; }
        public string Pgjlid { get; set; }
        public string Zbdxglid { get; set; }
        public DateTime? Sjqssj { get; set; }
        public DateTime? Sjjssj { get; set; }
    }
}
