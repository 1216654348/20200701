﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class HpfNbBhdcqk
    {
        public string Id { get; set; }
        public string Ndbgid { get; set; }
        public DateTime? Cjsj { get; set; }
        public string Ycyslxvalue { get; set; }
        public string Bhlxvalue { get; set; }
        public string Fxsjvalue { get; set; }
        public string Bhmsvalue { get; set; }
        public sbyte? Issctp { get; set; }
        public DateTime? Rksj { get; set; }
        public int? Sort { get; set; }
        public int? Wzxs { get; set; }
    }
}
