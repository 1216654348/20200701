﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcShstaticCopy1
    {
        public string Id { get; set; }
        public string Bmc { get; set; }
        public string Cjnum { get; set; }
        public string Tjnum { get; set; }
        public string Ytgnum { get; set; }
        public string Ygqnum { get; set; }
        public string Wshnum { get; set; }
        public string Shuser { get; set; }
        public string Jcx { get; set; }
        public string Rwjssj { get; set; }
        public string Sfszqxjc { get; set; }
        public string Fid { get; set; }
        public string Jcpzfaid { get; set; }
        public string Mc { get; set; }
        public string Date { get; set; }
    }
}
