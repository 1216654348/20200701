﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcPgZbsjjgb
    {
        public string Id { get; set; }
        public string Glid { get; set; }
        public double? Zbz { get; set; }
        public DateTime? Sjsj { get; set; }
        public DateTime? Cjsj { get; set; }
    }
}
