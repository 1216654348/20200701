﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class DtzyTcWms
    {
        public string Id { get; set; }
        public string Mc { get; set; }
        public string Bm { get; set; }
        public string Url { get; set; }
        public string Ztcj { get; set; }
        public sbyte? Sfwptc { get; set; }
        public string Wpgs { get; set; }
        public int? Wpkd { get; set; }
        public int? Wpgd { get; set; }
        public string Xybb { get; set; }
        public string Bz { get; set; }
        public string Zbck { get; set; }
        public string Tl { get; set; }
    }
}
