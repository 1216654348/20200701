﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcBcjcdx
    {
        public string Id { get; set; }
        public string Lx { get; set; }
        public double? Jd { get; set; }
        public double? Wd { get; set; }
        public string Mc { get; set; }
        public string Wzms { get; set; }
        public string Ycysid { get; set; }
        public string Zdmc { get; set; }
    }
}
