﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcYjxxfl0716改
    {
        public string Id { get; set; }
        public string Fid { get; set; }
        public string Yjfl { get; set; }
        public string Ejfl { get; set; }
    }
}
