﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcXgjlb
    {
        public string Id { get; set; }
        public string Xgdid { get; set; }
        public string Cjdid { get; set; }
        public DateTime Xgsj { get; set; }
        public DateTime? Tjsj { get; set; }
        public double? Dqjd { get; set; }
        public double? Dqwd { get; set; }
        public string Rwid { get; set; }
        public string Qkms { get; set; }
        public string Xgr { get; set; }
    }
}
