﻿using System;
using System.Collections.Generic;

namespace WebApplication1.LZModel
{
    public partial class GlyjcJzjc
    {
        public string Id { get; set; }
        public string Bh { get; set; }
        public string Zbx { get; set; }
        public string Zby { get; set; }
        public sbyte? Czlx { get; set; }
        public string Zp { get; set; }
        public sbyte? Bjsx { get; set; }
        public string Ssys { get; set; }
        public string Bczt { get; set; }
        public string Cjrid { get; set; }
        public DateTime? Cjsj { get; set; }
        public string Shrid { get; set; }
        public DateTime? Shsj { get; set; }
        public sbyte? Shzt { get; set; }
        public sbyte? Sfkdj { get; set; }
        public string Djrid { get; set; }
        public DateTime? Djsj { get; set; }
        public sbyte? Sfydj { get; set; }
        public string Shyc { get; set; }
        public DateTime? Tjsj { get; set; }
    }
}
